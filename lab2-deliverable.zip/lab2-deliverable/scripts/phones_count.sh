## Num of phones in dev
wc -w /home/eleanna/Desktop/master/nlp/nlp-labs/kaldi/egs/usc/data/dev/text
## Num of phones in test
wc -w /home/eleanna/Desktop/master/nlp/nlp-labs/kaldi/egs/usc/data/test/text
## Num of phones in train
wc -w /home/eleanna/Desktop/master/nlp/nlp-labs/kaldi/egs/usc/data/train/text